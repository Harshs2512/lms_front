import React from 'react'

export default function RecentAccessed() {
  return (
    <>
      <div className='border border-orange p-2   w-[100%] flex flex-col sm:flex-row justify-between px-5'>
            <div className='w-[100%] sm:w-[65%]   border border-black border border-white'>
              <div className='border border-gray bg-darkblue text-white  '>
                <h1>Recent Added Course</h1>
              </div>
              <div className='overflow-auto scrollbar-hide p-2 h-56'>
                <p>Colorlib content is free. When you buy through links on our site, we may earn an affiliate commission. Learn More
40 Free Bootstrap Admin Dashboard Templates For Your Web App 2023
May 23, 2023
 
Aigars Silkalns
 
Website Templates
 
55 Comments
Below are the most powerful and resourceful free Bootstrap admin dashboard templates. These easily fit all types of applications and projects for your convenience.

Bootstrap 5 is the latest version of Bootstrap and the most extensive web framework with many features, all easy to use. We’ve hand-picked the list of free Bootstrap 5 admin dashboard templates.

The focus of each template is different – some templates offer a wide range of customization while others focus on specific features. We’re sure you will find a template that suits your needs perfectly!

These simple yet powerful admin templates are well suited for web apps or any other website or project that requires the admin dashboard. These templates will be a solid foundation for your upcoming project and save you time.

Below listed free Bootstrap admin templates are rather simple and might not be the right fit for everyone. Check this template collection for more advanced and customizable admin templates.

This template collection will find HTML/CSS coded admin templates and some powered by React, Vue, Angular, and Bootstrap.

Best free & premium Bootstrap admin dashboard templates
              ArchitectUI HTML (Bootstrap 5)</p>
              </div>
            </div>

            <div className=' w-[100%] sm:w-[30%] mt-5 sm:mt-0 border border-black'>
            <div className='border border-gray bg-darkblue text-white'>
                <h1>Recent joined students</h1>
              </div>
              <div className='overflow-auto scrollbar-hide p-2 h-56'>
                <p>Colorlib content is free. When you buy through links on our site, we may earn an affiliate commission. Learn More
40 Free Bootstrap Admin Dashboard Templates For Your Web App 2023
May 23, 2023
 
Aigars Silkalns
 
Website Templates
 
55 Comments
Below are the most powerful and resourceful free Bootstrap admin dashboard templates. These easily fit all types of applications and projects for your convenience.

Bootstrap 5 is the latest version of Bootstrap and the most extensive web framework with many features, all easy to use. We’ve hand-picked the list of free Bootstrap 5 admin dashboard templates.

The focus of each template is different – some templates offer a wide range of customization while others focus on specific features. We’re sure you will find a template that suits your needs perfectly!

These simple yet powerful admin templates are well suited for web apps or any other website or project that requires the admin dashboard. These templates will be a solid foundation for your upcoming project and save you time.

Below listed free Bootstrap admin templates are rather simple and might not be the right fit for everyone. Check this template collection for more advanced and customizable admin templates.

This template collection will find HTML/CSS coded admin templates and some powered by React, Vue, Angular, and Bootstrap.

Best free & premium Bootstrap admin dashboard templates
              ArchitectUI HTML (Bootstrap 5)</p>
              </div>
              
            </div>
          </div> 
    </>
  )
}
